#' @title cvalue
#'
#' @description Función para calcular el o los Valores Criticos de una prueba de hipótesis Unilateral bilateral.
#'
#' @param alpha Valor del nivel de confianza (Debe ser un numero)
#'
#' @param HA Valor asignado segun la prueba (Debe ser un numero)
#'
#' @details Si HA>0 es una prueba unilateral de cola derecha (HA>U)
#' @details Si HA<0 es una prueba unilateral de cola izquierda (HA<U)
#' @details Si HA=0 es una prueba bilateral (Ho=U)
#'
#' @return valor o valores criticos segun sea la prueba unilateral o bilateral
#' @export
#'
#' @examples cvalue(0.95,-1)
#' @examples cvalue(0.95,0)
#' @examples cvalue(0.95,1)
cvalue<-function (alpha,HA){
  if (HA>0) {
    print(qnorm(alpha))
  } else if (HA<0) {
    print(qnorm(alpha)*-1)
  } else {
    print(qnorm(alpha)*-1)
    print(qnorm(alpha))
  }
}
